package bank.managment.system;

import java.sql.*;

public class Conn {
    //globally declare
    Connection c;
    Statement s;
    
    
    //constructor
    public Conn(){
        //exception 
        try {
            //class load
//            Class.forName(com.mysql.cj.jdbc.Driver); not neccessary to declare it
            
            //connection create
            c= DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","root");
            s=c.createStatement();
        }catch(Exception e){
           System.out.println(e);          
        }
    }

}
